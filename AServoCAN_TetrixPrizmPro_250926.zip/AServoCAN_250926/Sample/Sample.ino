#include <PRIZM_PRO.h> // include PRIZM Pro library
PRIZM prizm; // instantiate a PRIZM Pro object “prizm” so we can
#include "AServoCAN.h"

HardwareSerial mySerial(1);
AServoCAN aservo_can;

//static int last_axis_number = (int)AServoAxis::J4;
static int last_axis_number = (int)AServoAxis::J1;


uint8_t Axis4_ServoON(void);
uint8_t Axis4_SetPostionMode(void);
uint8_t Axis4_SetHommingMode(void);
uint8_t Axis4_Move( int32_t axis1_position, int32_t axis1_velocity, int32_t axis2_position, int32_t axis2_velocity, int32_t axis3_position, int32_t axis3_velocity, int32_t axis4_position, int32_t axis4_velocity);
// put your setup code here, to run once:

void setup() 
{

  Serial.begin(115200);
  prizm.PrizmBegin();
  aservo_can.begin(mySerial, 38400, 15, 16);
  Serial.println("Robowell");


  Serial.println("Start up");
  
  while(!Axis4_SetPostionMode()); // 위치 원점으로 이동
//  Axis4_SetHommingMode(); // 모든 원점 이동
//  Axis_Homming(1); // 개별 호밍

}

  // put your main code here, to run repeatedly:
void loop() 
{
  
  while(!Axis4_Move(0,0, 0,0, 0,0, 0,0));
  while(!Axis4_Move(10000,60, 0,0, 0,0, 0,0));
    delay(1000);
  while(!Axis4_Move(0,60, 0,0, 0,0, 0,0));


}

// 벨로시티 기준 : RPM 

// 1번 : 기어비 25, 1000 각도 → 호밍 : 포토센서 // 무조건 왼쪽으로 회전 // 검 01
// 2번 : Z축, 1회전에 2mm → 호밍 : 하단으로 이동 // 갈 02
// 3번 : 기어비 25, 1000 각도 →시작각도 // 빨 03
// 4번 : 기어비 25, 1000 각도 →시작각도 // 주 04


uint8_t Axis4_ServoReadyCheck(void)
{
  // bool allReady = true;
  // bool allTargetReached = true;
  // for(int i = 1; i <= last_axis_number; i++)
  // {
  //    allReady &= aservo_can.CanStartMotion((AServoAxis)i, AServoMode::Position);
  // }
  // if(allReady) return 1;
  // Serial.println("ServoCheck ReTry");
  // return 0;
}

uint8_t Axis4_ServoON(void)
{
  bool allReady = true;
  bool allTargetReached = true;
  for(int i = 1; i <= last_axis_number; i++)
  {
    if(aservo_can.ResetFault((AServoAxis)i))
    {
      allReady &=  aservo_can.ServoOn((AServoAxis)i);
    }
  }
  if(allReady) return 1;
  Serial.println("ServoON ReTry");
  return 0;
}

uint8_t Axis4_SetPostionMode(void)
{
  bool allReady = true;
  bool allTargetReached = true;

  for(int i = 1; i <= last_axis_number; i++)
  {
    if(aservo_can.ResetFault((AServoAxis)i))
    {
      Serial.print(1);Serial.println("Fault oK");
      if(aservo_can.SetMode((AServoAxis)i, AServoMode::Position))
      {
        Serial.print(1);Serial.println("Mode oK");
        if(aservo_can.ServoOn((AServoAxis)i))
        {
          allReady &= aservo_can.CanStartMotion((AServoAxis)i, AServoMode::Position);
        }
      }
    }
    else 
    {
      Serial.println("ResetFault Fail");
      if(aservo_can.SetMode((AServoAxis)i, AServoMode::Position))
      {
        Serial.println("##1 SET Servo Position Mode");
        if(aservo_can.ServoOn((AServoAxis)i))
        {
          Serial.println("##2 Servo ON");
          if(aservo_can.ServoOff((AServoAxis)i))
          {
            Serial.println("##3 Servo OFF");
            if(aservo_can.ServoOn((AServoAxis)i))
            {
              Serial.println("##4 Servo ON");
              allReady &= aservo_can.CanStartMotion((AServoAxis)i, AServoMode::Position);
            }
          }
        } 
      }
    }
  }
  if(allReady) 
  {
   Serial.println("SetPostionMode OK");
    return 1;
  }
  Serial.println("SetPostionMode ReTry");
  return 0;
}

uint8_t Axis4_SetHommingMode(void)
{
  bool allReady = true;
  bool allTargetReached = true;

  for(int i = 1; i <= last_axis_number; i++)
  {
    if(aservo_can.ResetFault((AServoAxis)i))
    {
      Serial.print(1);Serial.println("Fault oK");
      if(aservo_can.SetMode((AServoAxis)i, AServoMode::Homing))
      {
        Serial.print(1);Serial.println("Mode oK");
        if(aservo_can.ServoOn((AServoAxis)i))
        {
          allReady &= aservo_can.CanStartMotion((AServoAxis)i, AServoMode::Homing);
        }
      }
    }
    else 
    {
      Serial.println("ResetFault Fail");
      if(aservo_can.SetMode((AServoAxis)i, AServoMode::Homing))
      {
        Serial.println("##1 SET Servo SetHomming Mode");
        if(aservo_can.ServoOn((AServoAxis)i))
        {
          Serial.println("##2 Servo ON");
          if(aservo_can.ServoOff((AServoAxis)i))
          {
            Serial.println("##3 Servo OFF");
            if(aservo_can.ServoOn((AServoAxis)i))
            {
              Serial.println("##4 Servo ON");
              allReady &= aservo_can.CanStartMotion((AServoAxis)i, AServoMode::Homing);
            }
          }
        } 
      }
    }
  }
  if(allReady) 
  {
   Serial.println("SetHommingMode OK");
    return 1;
  }
  Serial.println("SetHommingMode ReTry");
  return 0;
}


uint8_t Axis4_Homming(void)
{
  bool allReady = true;
  bool allTargetReached = true;
  for(int i = 1; i <= last_axis_number; i++)
  {
    aservo_can.MoveHomming((AServoAxis)i);
  }
  while(1)
  {
    for(int i = 1; i <= last_axis_number; i++)
    {
      allTargetReached &= aservo_can.IsHommingReached((AServoAxis)i);
    } 
    if(allTargetReached)return 1;
  }  
  return 0;
}

uint8_t Axis_Homming(int nunber)
{
  bool allReady = true;
  bool allTargetReached = true;
    aservo_can.MoveHomming((AServoAxis)nunber);
  while(1)
  {
      allTargetReached &= aservo_can.IsHommingReached((AServoAxis)nunber);
    if(allTargetReached)return 1;
  }  
  return 0;
}



uint8_t Axis4_Move( int32_t axis1_position, int32_t axis1_velocity, int32_t axis2_position, int32_t axis2_velocity, int32_t axis3_position, int32_t axis3_velocity, int32_t axis4_position, int32_t axis4_velocity)
{
  bool allReady = true;
  bool allTargetReached = true;
  int32_t axis_position[4] = {axis1_position, axis2_position, axis3_position, axis4_position};
  int32_t axis_velocity[4] = {axis1_velocity, axis2_velocity, axis3_velocity, axis4_velocity};

  for(int i = 1; i <= last_axis_number; i++)
  {
    allTargetReached &= aservo_can.IsTargetReached((AServoAxis)i);
  }
  if(allTargetReached)
  {
    for(int i = 1; i <= last_axis_number; i++)
    {
      aservo_can.MoveAbs((AServoAxis)i, axis_position[i-1], axis_velocity[i-1]);
    }
    return 1;
  }
  return 0;
}
