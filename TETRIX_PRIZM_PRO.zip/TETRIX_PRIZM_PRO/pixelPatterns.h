/*#######################

  Pixel Patterns

####################### */

#define PATTERN_SPARKLE    1
#define PATTERN_CHASE      2
#define PATTERN_TWINKLE    3
#define PATTERN_SWEEP      4
#define PATTERN_RAINBOW    5
#define PATTERN_FADE       6
