/*************************************************

 * Public Constants for EFFECT EFFECTS

 *************************************************/

 #define  EFFECT_UFO          1
 #define  EFFECT_RANDOM       2
 #define  EFFECT_ALARM        3
 #define  EFFECT_WHISTLE_UP   4
 #define  EFFECT_WHISTLE_DOWN 5
 #define  EFFECT_SIREN        6
 #define  EFFECT_CORRECT      7
 #define  EFFECT_INCORRECT    8
